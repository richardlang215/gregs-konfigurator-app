# Gregs Konfigurátor 2.0.1 – web (server gregs-poptavky)

Novinky: tlačítko „Vytvořit přehledný návrh do PDF“ rovnou stáhne PDF (vždy světlé, včetně fotek se zákresy),
tisk je vždy ve světlém režimu a ke každé odeslané poptávce se automaticky přiloží PDF návrh.

Postup: nahraďte `static/index.html` na serveru a spusťte `docker compose up -d --build`.
Server musí u poptávky přijímat i soubory PDF (stejně jako přílohy od zákazníka).
