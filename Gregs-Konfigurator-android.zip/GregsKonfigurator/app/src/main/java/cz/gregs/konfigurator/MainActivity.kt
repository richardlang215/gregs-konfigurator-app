package cz.gregs.konfigurator

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.content.res.Configuration
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * Gregs Konfigurátor – Android obal webového konfigurátoru.
 *
 * Načte konfigurátor ze serveru Gregs (vždy aktuální verze a ceny). Bez internetu nebo když
 * server neodpovídá, použije kopii přibalenou v aplikaci (assets/index.html), která odesílá
 * poptávky a načítá ceny ze serveru přes API.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private var usingLocal = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    private val appHost: String = Uri.parse(BuildConfig.APP_URL).host ?: ""
    private var downloadId: Long = -1
    private var downloadReceiver: BroadcastReceiver? = null

    /** Po stažení aktualizace rovnou nabídneme instalaci. */
    fun awaitDownload(id: Long) {
        downloadId = id
        if (downloadReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val done = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: -1
                if (done == downloadId) UpdateChecker.install(this@MainActivity)
            }
        }
        downloadReceiver = receiver
        ContextCompat.registerReceiver(this, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED)
    }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private var cameraFile: File? = null

    /** Jeden spouštěč pro fotoaparát i výběr souborů – výsledek se vyhodnotí podle toho, co přišlo zpět. */
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val picked = mutableListOf<Uri>()
        res.data?.clipData?.let { c -> for (i in 0 until c.itemCount) c.getItemAt(i).uri?.let { if (it != cameraUri) picked += it } }
        res.data?.data?.let { if (it != cameraUri && it !in picked) picked += it }
        val f = cameraFile
        // Některé aplikace fotoaparátu nevrací správný výsledek – rozhoduje, zda se fotka opravdu uložila.
        if (picked.isEmpty() && f != null && f.length() > 0) cameraUri?.let { picked += it }
        cameraFile = null
        if (picked.isEmpty() && res.resultCode == RESULT_OK && f != null) {
            Toast.makeText(this, "Fotka se neuložila, zkuste to prosím znovu.", Toast.LENGTH_LONG).show()
        }
        deliver(picked.takeIf { it.isNotEmpty() }?.toTypedArray())
    }

    private fun cameraIntent(): Intent {
        val dir = File(cacheDir, "photos").apply { mkdirs() }
        val file = File(dir, "foto_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        cameraFile = file
        cameraUri = uri
        return Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            clipData = ClipData.newRawUri("foto", uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        // Tmavý pruh pod stavovou lištou navazuje na tmavou hlavičku s logem.
        val statusBg = View(this).apply { setBackgroundColor(0xFF121820.toInt()) }
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(statusBg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, Gravity.TOP))
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 8, Gravity.TOP))
        setContentView(root)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = !night
        }

        // Obsah mimo systémové lišty (Android 15 vykresluje aplikace pod lištami).
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            (web.layoutParams as FrameLayout.LayoutParams).setMargins(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            web.requestLayout()
            statusBg.layoutParams.height = bars.top
            statusBg.requestLayout()
            (progress.layoutParams as FrameLayout.LayoutParams).topMargin = bars.top
            progress.requestLayout()
            WindowInsetsCompat.CONSUMED
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true     // přístup k fotkám z fotoaparátu a galerie (content://)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            userAgentString = "$userAgentString GregsApp/${BuildConfig.VERSION_NAME}"
        }
        web.addJavascriptInterface(Bridge(), "GregsApp")
        web.webViewClient = Client()
        web.webChromeClient = Chrome()

        onBackPressedDispatcher.addCallback(this, backCallback)

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(BuildConfig.APP_URL)
    }

    private val backCallback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.gregsBack && window.gregsBack()) ? 1 : 0") { r ->
                    when {
                        r == "1" -> Unit                       // krok zpět v průvodci
                        web.canGoBack() -> web.goBack()
                        else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                    }
                }
            }
        }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        backCallback.isEnabled = true     // po návratu do aplikace znovu obsluhovat tlačítko Zpět
        UpdateChecker.check(this)
    }

    override fun onDestroy() {
        downloadReceiver?.let { runCatching { unregisterReceiver(it) } }
        downloadReceiver = null
        super.onDestroy()
    }

    private fun loadLocal() {
        if (usingLocal) return
        usingLocal = true
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun deliver(uris: Array<Uri>?) {
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    private fun openExternal(uri: Uri) {
        val intent = when (uri.scheme) {
            "mailto" -> Intent(Intent.ACTION_SENDTO, uri)
            "tel" -> Intent(Intent.ACTION_DIAL, uri)
            else -> Intent(Intent.ACTION_VIEW, uri)
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Pro tento odkaz není v telefonu žádná aplikace.", Toast.LENGTH_LONG).show()
        }
    }

    private inner class Client : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
            assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url
            val internal = (u.scheme == "https" || u.scheme == "http") &&
                (u.host == appHost || u.host == "appassets.androidplatform.net")
            if (internal) return false
            openExternal(u)
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            progress.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String?) {
            progress.visibility = View.GONE
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) loadLocal()
        }

        override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
            if (request.isForMainFrame && response.statusCode >= 400) loadLocal()
        }
    }

    private inner class Chrome : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.progress = newProgress
        }

        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: FileChooserParams,
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = callback
            val types = params.acceptTypes.flatMap { it.split(",") }.map { it.trim() }.filter { it.contains("/") }
            val wantsImages = types.isEmpty() || types.any { it.startsWith("image") || it == "*/*" }
            val pick = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = if (types.size == 1) types[0] else "*/*"
                if (types.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, types.toTypedArray())
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
            }
            // 1) tlačítko Vyfotit -> rovnou fotoaparát
            if (params.isCaptureEnabled) {
                try {
                    chooser.launch(cameraIntent())
                    return true
                } catch (e: Exception) {
                    cameraFile = null
                    Toast.makeText(this@MainActivity, "Fotoaparát se nepodařilo otevřít, vyberte fotku z galerie.", Toast.LENGTH_LONG).show()
                }
            }
            // 2) výběr souborů, v nabídce je i fotoaparát
            try {
                val camera = if (wantsImages) runCatching { cameraIntent() }.getOrNull() else null
                val intent = Intent.createChooser(pick, "Přidat fotky").apply {
                    if (camera != null) putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(camera))
                }
                chooser.launch(intent)
            } catch (e: Exception) {
                cameraFile = null
                deliver(null)
                Toast.makeText(this@MainActivity, "Výběr souborů není dostupný: ${e.message}", Toast.LENGTH_LONG).show()
            }
            return true
        }
    }

    private fun savePdfFile(bytes: ByteArray, name: String) {
        try {
            val dir = File(cacheDir, "pdf").apply { mkdirs() }
            val file = File(dir, name)
            file.writeBytes(bytes)
            var saved = false
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                runCatching {
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    }
                    contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)?.let { u ->
                        contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                        saved = true
                    }
                }
            }
            Toast.makeText(this, if (saved) "PDF uloženo do složky Stažené: $name" else "PDF návrh je připravený", Toast.LENGTH_LONG).show()
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(view) } catch (e: ActivityNotFoundException) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Sdílet PDF návrh"))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "PDF se nepodařilo uložit: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun safeName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "priloha" }

    private fun shareFilesNow(json: String) {
        try {
            val o = org.json.JSONObject(json)
            val dir = File(cacheDir, "share").apply { deleteRecursively(); mkdirs() }
            val uris = ArrayList<Uri>()
            val arr = o.optJSONArray("files") ?: org.json.JSONArray()
            for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val bytes = android.util.Base64.decode(f.getString("data"), android.util.Base64.DEFAULT)
                val file = File(dir, safeName(f.optString("name", "priloha_$i")))
                file.writeBytes(bytes)
                uris.add(FileProvider.getUriForFile(this, "$packageName.files", file))
            }
            val send = Intent(if (uris.size > 1) Intent.ACTION_SEND_MULTIPLE else Intent.ACTION_SEND).apply {
                type = if (uris.isEmpty()) "text/plain" else "*/*"
                putExtra(Intent.EXTRA_EMAIL, arrayOf(o.optString("to")))
                putExtra(Intent.EXTRA_SUBJECT, o.optString("subject"))
                putExtra(Intent.EXTRA_TEXT, o.optString("body"))
                if (uris.size > 1) putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                else if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris[0])
                if (uris.isNotEmpty()) {
                    val clip = ClipData.newRawUri("priloha", uris[0])
                    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                    clipData = clip
                }
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Odeslat poptávku e-mailem"))
        } catch (e: Exception) {
            Toast.makeText(this, "Přílohy se nepodařilo připravit: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveToDownloads(bytes: ByteArray, name: String, mime: String) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                }
                contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)?.let { u ->
                    contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                    Toast.makeText(this, "Uloženo do složky Stažené: $name", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            // starší Android: nabídnout sdílení / uložení
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val file = File(dir, name).apply { writeBytes(bytes) }
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Uložit soubor"))
        } catch (e: Exception) {
            Toast.makeText(this, "Soubor se nepodařilo uložit: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Funkce dostupné ze stránky jako window.GregsApp */
    private inner class Bridge {
        @JavascriptInterface
        fun checkUpdate() {
            runOnUiThread { UpdateChecker.check(this@MainActivity, force = true) }
        }

        @JavascriptInterface
        fun version(): String = BuildConfig.VERSION_NAME

        /** Uloží PDF návrh do Stažených a rovnou ho otevře. */
        @JavascriptInterface
        fun savePdf(base64: String, name: String) {
            val bytes = try { android.util.Base64.decode(base64, android.util.Base64.DEFAULT) } catch (e: Exception) { return }
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").let { if (it.endsWith(".pdf")) it else "Gregs-navrh.pdf" }
            runOnUiThread { savePdfFile(bytes, safe) }
        }

        /** E-mail s přílohami (fotky, PDF), když se poptávku nepodaří odeslat na server. */
        @JavascriptInterface
        fun shareFiles(json: String) {
            runOnUiThread { shareFilesNow(json) }
        }

        /** Uloží libovolný soubor (fotku, PDF) do složky Stažené. */
        @JavascriptInterface
        fun saveFile(base64: String, name: String, mime: String) {
            val bytes = try { android.util.Base64.decode(base64, android.util.Base64.DEFAULT) } catch (e: Exception) { return }
            runOnUiThread { saveToDownloads(bytes, safeName(name), mime) }
        }

        @JavascriptInterface
        fun print() {
            runOnUiThread {
                val pm = getSystemService(PrintManager::class.java)
                pm.print("Gregs – návrh", web.createPrintDocumentAdapter("Gregs-navrh"), PrintAttributes.Builder().build())
            }
        }
    }
}
