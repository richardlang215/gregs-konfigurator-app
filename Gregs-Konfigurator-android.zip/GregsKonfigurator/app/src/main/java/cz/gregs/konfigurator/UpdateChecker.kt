package cz.gregs.konfigurator

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.core.content.edit
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Kontrola nové verze aplikace proti serveru Gregs.
 *
 * Server vrací na adrese PUBLIC_URL/api/verze:
 *   { "versionCode": 11, "versionName": "2.0", "url": "https://…/app.apk", "notes": "Co je nového" }
 *
 * Instalace APK vyžaduje, aby uživatel jednou povolil instalaci z této aplikace.
 * Systém se zeptá sám, my ho jen nasměrujeme do nastavení.
 */
object UpdateChecker {

    private const val PREFS = "update"
    private const val LAST_CHECK = "lastCheck"
    private const val SKIPPED = "skippedVersion"
    private const val INTERVAL = 12 * 60 * 60 * 1000L      // kontrolovat nejvýš dvakrát denně
    private val pool = Executors.newSingleThreadExecutor()

    data class Update(val code: Int, val name: String, val url: String, val notes: String)

    /** Zkontroluje novou verzi na pozadí. [force] = na výslovné přání uživatele. */
    fun check(activity: MainActivity, force: Boolean = false) {
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong(LAST_CHECK, 0) < INTERVAL) return

        pool.execute {
            val update = fetch()
            activity.runOnUiThread {
                prefs.edit { putLong(LAST_CHECK, now) }
                when {
                    update == null ->
                        if (force) Toast.makeText(activity, "Aktualizaci se nepodařilo ověřit.", Toast.LENGTH_SHORT).show()

                    update.code <= BuildConfig.VERSION_CODE ->
                        if (force) Toast.makeText(activity, "Máte nejnovější verzi.", Toast.LENGTH_SHORT).show()

                    !force && prefs.getInt(SKIPPED, 0) == update.code -> Unit   // uživatel ji odložil

                    else -> ask(activity, update, prefs)
                }
            }
        }
    }

    private fun fetch(): Update? = try {
        val url = URL(BuildConfig.APP_URL.trimEnd('/') + "/api/verze")
        (url.openConnection() as HttpURLConnection).run {
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("Accept", "application/json")
            try {
                if (responseCode != 200) null
                else JSONObject(inputStream.bufferedReader().readText()).let {
                    val link = it.optString("url")
                    if (!link.startsWith("https://")) null
                    else Update(it.optInt("versionCode"), it.optString("versionName"), link, it.optString("notes"))
                }
            } finally {
                disconnect()
            }
        }
    } catch (e: Exception) {
        Log.i("UpdateChecker", "kontrola verze selhala: ${e.message}")
        null
    }

    private fun ask(activity: MainActivity, u: Update, prefs: android.content.SharedPreferences) {
        AlertDialog.Builder(activity)
            .setTitle("Je k dispozici verze ${u.name}")
            .setMessage(u.notes.ifBlank { "Stáhnout a nainstalovat novou verzi aplikace?" })
            .setPositiveButton("Stáhnout") { _, _ -> download(activity, u) }
            .setNegativeButton("Později", null)
            .setNeutralButton("Přeskočit") { _, _ -> prefs.edit { putInt(SKIPPED, u.code) } }
            .show()
    }

    private fun download(activity: MainActivity, u: Update) {
        try {
            val dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            File(dir, "update.apk").delete()
            val req = DownloadManager.Request(Uri.parse(u.url))
                .setTitle("Gregs ${u.name}")
                .setDescription("Stahuji aktualizaci")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, "update.apk")
                .setMimeType("application/vnd.android.package-archive")
            val id = activity.getSystemService(DownloadManager::class.java).enqueue(req)
            activity.awaitDownload(id)
            Toast.makeText(activity, "Stahuji aktualizaci…", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Stažení se nepodařilo: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Spustí systémový instalátor nad staženým souborem. */
    fun install(activity: MainActivity) {
        val file = File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "update.apk")
        if (!file.isFile || file.length() < 1000) {
            Toast.makeText(activity, "Stažený soubor se nenašel.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity)
                .setTitle("Povolte instalaci")
                .setMessage("Android chce vaše svolení, aby aplikace Gregs mohla nainstalovat aktualizaci. " +
                        "Povolte to v nastavení a pak se vraťte zpět.")
                .setPositiveButton("Otevřít nastavení") { _, _ ->
                    activity.startActivity(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
                }
                .setNegativeButton("Zrušit", null)
                .show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.files", file)
        activity.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}
