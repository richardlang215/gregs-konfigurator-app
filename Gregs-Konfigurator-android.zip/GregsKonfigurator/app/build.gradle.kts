import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ks = Properties().apply {
    val f = file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "cz.gregs.konfigurator"
    compileSdk = 35

    defaultConfig {
        applicationId = "cz.gregs.konfigurator"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "1.6"
        // Adresa serveru s konfigurátorem. Když není dostupná, použije se kopie přibalená v aplikaci.
        buildConfigField("String", "APP_URL", "\"https://konfigurator.gregs.cz/\"")
    }

    signingConfigs {
        create("release") {
            storeFile = file(ks.getProperty("storeFile", "gregs-release.jks"))
            storePassword = ks.getProperty("storePassword")
            keyAlias = ks.getProperty("keyAlias")
            keyPassword = ks.getProperty("keyPassword")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
