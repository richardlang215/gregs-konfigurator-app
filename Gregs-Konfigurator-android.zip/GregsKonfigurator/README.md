# Gregs Konfigurátor – Android aplikace

Aplikace pro zákazníky: konfigurátor zabezpečení a chytré budovy Gregs v telefonu.

- Načítá konfigurátor ze serveru Gregs (`APP_URL`, výchozí `https://konfigurator.gregs.cz/`),
  takže zákazník má vždy aktuální verzi a ceny z Odoo.
- **Bez internetu** nebo když server neodpovídá, použije kopii přibalenou v aplikaci
  (`app/src/main/assets/index.html`). Ta odesílá poptávky a načítá ceny ze serveru přes API.
- **Fotky:** tlačítko *Vyfotit* otevře fotoaparát, *Vybrat soubory* galerii nebo soubory (i PDF).
- **Tisk / PDF** návrhu přes systémový tisk Androidu (lze uložit jako PDF).
- Odkazy na telefon a e-mail otevřou vytáčení a poštu, ostatní odkazy prohlížeč.
- Tlačítko **Zpět** vrací o krok v průvodci.
- Rozpracovaný návrh si aplikace pamatuje.

## Sestavení přes GitHub (bez počítače)

1. Založte **nový soukromý** repozitář, např. `gregs-konfigurator-app`.
2. Nahrajte ZIP s projektem (Add file → Upload files).
3. Do `.github/workflows/` nahrajte `build.yml` z tohoto balíčku.
4. Za pár minut je APK v *Releases → latest*.

V Android Studiu: *File → Open*, pak *Build → Build APK(s)*.

## Podpis aplikace – důležité

Projekt obsahuje podpisový klíč `app/gregs-release.jks` a hesla v `app/keystore.properties`.
Díky stejnému klíči se nové verze instalují přes starou bez odinstalace.

- **Klíč si zálohujte** – bez něj nepůjde vydat aktualizaci.
- Repozitář musí zůstat **soukromý**. Do budoucna je lepší hesla přesunout do GitHub Secrets.
- Před vydáním nové verze zvyšte `versionCode` (a `versionName`) v `app/build.gradle.kts`.

## Server

Aplikace potřebuje server **gregs-poptavky** na adrese `APP_URL` (stejná adresa je
v konfigurátoru jako `CONFIG.APP_API_BASE`). Server musí povolit původ
`https://appassets.androidplatform.net` (proměnná `CORS_ORIGINS`, výchozí hodnota to už dělá).

Jiná doména: změňte `APP_URL` v `app/build.gradle.kts` a `APP_API_BASE`
v `app/src/main/assets/index.html` (i ve `static/index.html` na serveru).

## Distribuce zákazníkům

- **Odkaz na webu gregs.cz** nebo QR kód na letáku, který vede na APK. Zákazník musí povolit
  instalaci z neznámých zdrojů – pro běžné zákazníky je to bariéra.
- **Google Play** (doporučeno pro zákazníky): vývojářský účet Google (jednorázový poplatek),
  odkaz na zásady ochrany osobních údajů a sestavení AAB: `gradle bundleRelease`.
  Aplikace je na to připravená, stačí doplnit popis a screenshoty.
