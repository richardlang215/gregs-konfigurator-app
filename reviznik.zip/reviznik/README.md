# Revizník – samostatná webová verze

Hlídač revizí a termínů (komín, kotel, STK, pneu, pojištění, elektro…) v jednom souboru index.html.

## Spuštění
- Otevřete index.html v prohlížeči, nebo ho nahrajte na jakýkoli web (Vercel, hosting, NAS).
- Data se ukládají jen v tomto prohlížeči (localStorage). Jiný telefon nebo počítač je neuvidí.
- Export do CSV: tlačítko Export.

## Rozdíl oproti verzi v Claude
Verze na claude.ai ukládá termíny do soukromého úložiště účtu Claude a funguje na všech zařízeních.
Tahle samostatná verze je prototyp: pro placenou službu s účty, synchronizací a připomínkami
e-mailem a SMS je potřeba backend (plánováno: Supabase + Vercel, Stripe, Brevo).
