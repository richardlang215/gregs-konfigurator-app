# Gregs Konfigurátor 2.0 – pravidla hesla i na serveru

Webová stránka v2.0 hlídá heslo už při registraci. Aby to nešlo obejít, doplňte stejnou kontrolu do serveru **gregs-poptavky**.

## 1. Do `app/auth.py` přidejte na konec

```python
PW_MIN, PW_MAX = 10, 64
PW_SYMBOLS = "!@#$%&*?-_+=."
_PW_ALLOWED = re.compile(r"^[A-Za-z0-9!@#$%&*?\-_+=.]+$")


def password_problem(pwd: str, email: str = "") -> str | None:
    """Vrátí text chyby, nebo None, když heslo vyhovuje."""
    if not (PW_MIN <= len(pwd) <= PW_MAX):
        return f"Heslo musí mít {PW_MIN} až {PW_MAX} znaků."
    if not _PW_ALLOWED.match(pwd):
        return "Heslo nesmí obsahovat mezery ani diakritiku."
    if not re.search(r"[A-Z]", pwd) or not re.search(r"[a-z]", pwd):
        return "Heslo musí obsahovat velké i malé písmeno."
    if not re.search(r"[0-9]", pwd):
        return "Heslo musí obsahovat číslici."
    if not any(c in PW_SYMBOLS for c in pwd):
        return "Heslo musí obsahovat speciální znak: " + " ".join(PW_SYMBOLS)
    local = email.split("@")[0].lower()
    if len(local) >= 4 and local in pwd.lower():
        return "Heslo nesmí obsahovat váš e-mail."
    return None
```

## 2. V `app/main.py`, funkce `register`, nahraďte

```python
    if len(pwd) < 8:
        return JSONResponse({"ok": False, "error": "Heslo musí mít alespoň 8 znaků."}, 400)
```

tímto:

```python
    problem = auth.password_problem(pwd, email)
    if problem:
        return JSONResponse({"ok": False, "error": problem}, 400)
```

## 3. Restart

```
docker compose up -d --build
```

Stávající účty s kratším heslem se dál přihlásí, pravidla platí jen pro nové registrace.
