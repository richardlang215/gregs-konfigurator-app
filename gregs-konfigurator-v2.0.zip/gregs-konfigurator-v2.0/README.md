# Gregs Konfigurátor 2.0 – aktualizace

Tento balíček aktualizuje existující server **gregs-web** (gregs-poptavky) na verzi 2.0.

## Postup
1. Soubor `static/index.html` z tohoto ZIPu nahraďte do složky `static/` na serveru.
2. Podle `SERVER-HESLO.md` doplňte kontrolu hesla do `app/auth.py` a `app/main.py`.
3. Restart: `docker compose up -d --build`

## Jen web bez serveru
Stačí nahrát `static/index.html` kamkoli na gregs.cz (např. `gregs.cz/konfigurator/index.html`).
